import { masterData } from "@/services/masterData.service";
import { Meter, MeterForm, createMeterColumns } from "./meter-config";
import {
  ReadingType,
  ReadingTypeForm,
  createReadingTypeColumns,
} from "./reading-type-config";
import {
  PriceScheme,
  PriceSchemeForm,
  createPriceSchemeColumns,
} from "./price-scheme-config";
import {
  EfficiencyTarget,
  EfficiencyTargetForm,
  createEfficiencyTargetColumns,
} from "./target-config";
import { PriceSchemeTable } from "./tableSheme";

// Tipe untuk item data di tabel
export type MasterDataItem =
  | Meter
  | ReadingType
  | PriceScheme
  | EfficiencyTarget;
// Tipe untuk kunci sub-menu
export type SubMenuKey = keyof typeof SUB_MENU_CONFIG;

// Objek konfigurasi utama yang mengatur setiap tab
export const SUB_MENU_CONFIG = {
  meters: {
    title: "Meter",
    columns: createMeterColumns,
    filterKey: "meter_code",
    idKey: "meter_id",
    api: masterData.meter,
    FormComponent: MeterForm,
  },
  reading_types: {
    title: "Tipe Pembacaan",
    columns: createReadingTypeColumns,
    filterKey: "type_name",
    idKey: "reading_type_id",
    api: masterData.readingType,
    FormComponent: ReadingTypeForm,
  },
  price_schemes: {
    title: "Skema Harga",
    columns: PriceSchemeTable,
    filterKey: "scheme_name",
    idKey: "scheme_id",
    api: masterData.priceScheme,
    FormComponent: PriceSchemeForm,
  },
  efficiency_targets: {
    title: "Target Efisiensi",
    columns: createEfficiencyTargetColumns,
    filterKey: "kpi_name",
    idKey: "target_id",
    api: masterData.efficiencyTarget,
    FormComponent: EfficiencyTargetForm,
  },
};
