"use client";

import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ColumnDef } from "@tanstack/react-table";
import { MoreHorizontal } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Tipe data berdasarkan Prisma Schema
export type Meter = {
  meter_id: number;
  meter_code: string;
  location: string | null;
  status: "Active" | "UnderMaintenance" | "Inactive" | "DELETED";
  energy_type: EnergyType; // <-- Relasi disertakan di sini
};

const meterSchema = z.object({
  meter_code: z.string().min(1, "Kode meter tidak boleh kosong."),
  location: z.string().optional(),
  status: z.enum(["Active", "UnderMaintenance", "Inactive", "DELETED"]),
});

// --- Komponen Form untuk Tambah/Edit ---
interface MeterFormProps {
  initialData?: Meter | null;
  onSubmit: (values: z.infer<typeof meterSchema>) => void;
  isLoading?: boolean;
}

export function MeterForm({
  initialData,
  onSubmit,
  isLoading,
}: MeterFormProps) {
  const form = useForm<z.infer<typeof meterSchema>>({
    resolver: zodResolver(meterSchema),
    defaultValues: initialData || {
      meter_code: "",
      location: "",
      status: "Active",
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="meter_code"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Kode Meter</FormLabel>
              <FormControl>
                <Input placeholder="Contoh: MTR-001" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Lokasi</FormLabel>
              <FormControl>
                <Input placeholder="Contoh: Gedung Terminal A" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="status"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Status</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih status" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="Active">Aktif</SelectItem>
                  <SelectItem value="UnderMaintenance">
                    Dalam Perbaikan
                  </SelectItem>
                  <SelectItem value="Inactive">Tidak Aktif</SelectItem>
                  <SelectItem value="DELETED">Dihapus</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="flex justify-end pt-4">
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Menyimpan..." : "Simpan"}
          </Button>
        </div>
      </form>
    </Form>
  );
}

// --- Definisi Kolom untuk DataTable ---
export const createMeterColumns = (
  onEdit: (item: Meter) => void,
  onDelete: (item: Meter) => void
): ColumnDef<Meter>[] => [
  { accessorKey: "meter_code", header: "Kode Meter" },
  { accessorKey: "location", header: "Lokasi" },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.original.status;
      const variant =
        status === "Active"
          ? "default"
          : status === "DELETED"
          ? "destructive"
          : "secondary";
      return <Badge variant={variant}>{status}</Badge>;
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const item = row.original;
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Aksi</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => onEdit(item)}>
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => onDelete(item)}
              className="text-red-600"
            >
              Hapus
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];
