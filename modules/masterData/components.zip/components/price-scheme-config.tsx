"use client";

import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ColumnDef } from "@tanstack/react-table";
import { MoreHorizontal, CalendarIcon } from "lucide-react";
import { format } from "date-fns";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export type PriceScheme = {
  scheme_id: number;
  scheme_name: string;
  effective_date: Date;
};

const priceSchemeSchema = z.object({
  scheme_name: z.string().min(1, "Nama skema tidak boleh kosong."),
  effective_date: z.date({ error: "Tanggal efektif harus diisi." }),
});

interface PriceSchemeFormProps {
  initialData?: PriceScheme | null;
  onSubmit: (values: z.infer<typeof priceSchemeSchema>) => void;
  isLoading?: boolean;
}

export function PriceSchemeForm({
  initialData,
  onSubmit,
  isLoading,
}: PriceSchemeFormProps) {
  const form = useForm<z.infer<typeof priceSchemeSchema>>({
    resolver: zodResolver(priceSchemeSchema),
    defaultValues: initialData
      ? { ...initialData, effective_date: new Date(initialData.effective_date) }
      : { scheme_name: "" },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="scheme_name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Nama Skema Harga</FormLabel>
              <FormControl>
                <Input placeholder="Contoh: Tarif Listrik 2025" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="effective_date"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <FormLabel>Tanggal Efektif</FormLabel>
              <Popover>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "pl-3 text-left font-normal",
                        !field.value && "text-muted-foreground"
                      )}
                    >
                      {field.value ? (
                        format(field.value, "PPP")
                      ) : (
                        <span>Pilih tanggal</span>
                      )}
                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={field.value}
                    onSelect={field.onChange}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="flex justify-end pt-4">
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Menyimpan..." : "Simpan"}
          </Button>
        </div>
      </form>
    </Form>
  );
}

export const createPriceSchemeColumns = (
  onEdit: (item: PriceScheme) => void,
  onDelete: (item: PriceScheme) => void
): ColumnDef<PriceScheme>[] => [
  { accessorKey: "scheme_name", header: "Nama Skema" },
  {
    accessorKey: "effective_date",
    header: "Tanggal Efektif",
    cell: ({ row }) =>
      format(new Date(row.original.effective_date), "dd MMMM yyyy"),
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const item = row.original;
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Aksi</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => onEdit(item)}>
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => onDelete(item)}
              className="text-red-600"
            >
              Hapus
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];
