"use client";

import React, { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PlusCircle, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

// Komponen & Utilitas
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DataTable } from "./dataTable";
import { ManagementDialog } from "./ManagementDialog";

// Konfigurasi & Tipe Data
import { masterData } from "@/services/masterData.service";
import { MasterDataItem, SUB_MENU_CONFIG, SubMenuKey } from "./config";
import type { EnergyType } from "@/types/energyType.types"; // Asumsi path tipe

export const Page = () => {
  const queryClient = useQueryClient();

  const [selectedEnergyTypeId, setSelectedEnergyTypeId] = useState<
    number | null
  >(null);
  const [activeSubMenu, setActiveSubMenu] = useState<SubMenuKey>("meters");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MasterDataItem | null>(null);
  const [itemToDelete, setItemToDelete] = useState<MasterDataItem | null>(null);

  // --- Data Fetching ---
  const { data: energyTypesResponse, isLoading: isLoadingEnergyTypes } =
    useQuery({
      queryKey: ["energyTypes"],
      queryFn: masterData.energyType.getAll,
    });
  // PERBAIKAN: Akses array dari properti '.data'
  const energyTypes: EnergyType[] = energyTypesResponse?.data || [];

  useEffect(() => {
    if (energyTypes.length > 0 && !selectedEnergyTypeId) {
      setSelectedEnergyTypeId(energyTypes[0].energy_type_id);
    }
  }, [energyTypes, selectedEnergyTypeId]);

  const config = SUB_MENU_CONFIG[activeSubMenu];
  const { FormComponent } = config;

  const { data: tableDataResponse, isLoading: isLoadingTableData } = useQuery({
    queryKey: [activeSubMenu, selectedEnergyTypeId],
    queryFn: () => config.api.getByEnergyType(selectedEnergyTypeId!),
    enabled: !!selectedEnergyTypeId,
  });
  const tableData = tableDataResponse?.data || [];

  // --- Data Mutation ---
  const { mutate: createOrUpdateItem, isPending: isMutating } = useMutation({
    mutationFn: (itemData: any) => {
      const id = editingItem
        ? editingItem[config.idKey as keyof typeof editingItem]
        : undefined;
      const payload = { ...itemData, energy_type_id: selectedEnergyTypeId };
      return id ? config.api.update(id, payload) : config.api.create(payload);
    },
    onSuccess: () => {
      toast.success(`${config.title} berhasil disimpan!`);
      queryClient.invalidateQueries({
        queryKey: [activeSubMenu, selectedEnergyTypeId],
      });
      setIsModalOpen(false);
      setEditingItem(null);
    },
    onError: (error: any) => {
      toast.error(
        `Gagal menyimpan: ${error.response?.data?.message || error.message}`
      );
    },
  });

  const { mutate: deleteItem, isPending: isDeleting } = useMutation({
    mutationFn: (item: MasterDataItem) =>
      config.api.delete(item[config.idKey as keyof typeof item]),
    onSuccess: () => {
      toast.success(`${config.title} berhasil dihapus!`);
      queryClient.invalidateQueries({
        queryKey: [activeSubMenu, selectedEnergyTypeId],
      });
      setItemToDelete(null);
    },
    onError: (error: any) => {
      toast.error(
        `Gagal menghapus: ${error.response?.data?.message || error.message}`
      );
    },
  });

  // --- Handlers ---
  const handleOpenModal = (item: MasterDataItem | null = null) => {
    setEditingItem(item);
    setIsModalOpen(true);
  };
  const handleDeleteRequest = (item: MasterDataItem) => {
    setItemToDelete(item);
  };

  // --- Memoized Values ---
  const memoizedColumns = useMemo(
    () => config.columns(handleOpenModal, handleDeleteRequest),
    [config]
  );
  const selectedEnergyTypeName = useMemo(
    () =>
      energyTypes.find((e) => e.energy_type_id === selectedEnergyTypeId)
        ?.type_name || "",
    [energyTypes, selectedEnergyTypeId]
  );

  // --- JSX ---
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold">Manajemen Data Master</h1>
          <p className="text-muted-foreground">
            Kelola data inti sistem untuk {selectedEnergyTypeName || "..."}.
          </p>
        </div>
        <Button
          onClick={() => handleOpenModal()}
          disabled={!selectedEnergyTypeId}
        >
          <PlusCircle className="mr-2 h-4 w-4" /> Tambah {config.title}
        </Button>
      </div>

      <Tabs
        value={selectedEnergyTypeId?.toString()}
        onValueChange={(val) => setSelectedEnergyTypeId(Number(val))}
      >
        <TabsList className="grid w-full grid-cols-3">
          {isLoadingEnergyTypes ? (
            <Loader2 className="animate-spin mx-auto" />
          ) : (
            energyTypes.map((et) => (
              <TabsTrigger
                key={et.energy_type_id}
                value={et.energy_type_id.toString()}
              >
                {et.type_name}
              </TabsTrigger>
            ))
          )}
        </TabsList>
      </Tabs>

      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {(Object.keys(SUB_MENU_CONFIG) as SubMenuKey[]).map((key) => (
          <Button
            key={key}
            variant={activeSubMenu === key ? "default" : "outline"}
            onClick={() => setActiveSubMenu(key)}
          >
            Manajemen {SUB_MENU_CONFIG[key].title}
          </Button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={`${activeSubMenu}-${selectedEnergyTypeId}`}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>
                Daftar {config.title} untuk {selectedEnergyTypeName}
              </CardTitle>
              <CardDescription>
                Berikut adalah daftar semua {config.title.toLowerCase()} yang
                terdaftar.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DataTable
                columns={memoizedColumns}
                data={tableData}
                isLoading={isLoadingTableData}
                filterColumnId={config.filterKey}
                filterPlaceholder={`Cari berdasarkan ${config.filterKey.replace(
                  "_",
                  " "
                )}...`}
              />
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>

      <ManagementDialog
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`${editingItem ? "Edit" : "Tambah"} ${config.title}`}
      >
        <FormComponent
          initialData={editingItem}
          onSubmit={createOrUpdateItem}
          isLoading={isMutating}
        />
      </ManagementDialog>

      <AlertDialog
        open={!!itemToDelete}
        onOpenChange={() => setItemToDelete(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda Yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Aksi ini tidak dapat dibatalkan. Ini akan menghapus data '
              {itemToDelete?.[config.filterKey as keyof typeof itemToDelete]}'
              secara permanen.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteItem(itemToDelete!)}
              disabled={isDeleting}
            >
              {isDeleting ? "Menghapus..." : "Ya, Hapus"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
